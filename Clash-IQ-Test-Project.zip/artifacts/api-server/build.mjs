import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { rm } from "node:fs/promises";

globalThis.require = createRequire(import.meta.url);

const artifactDir = path.dirname(fileURLToPath(import.meta.url));

async function buildAll() {
  const { build: esbuild, version: esbuildVersion } = await import("esbuild");
  const distDir = path.resolve(artifactDir, "dist");

  console.error(`[Clash IQ] API build starting — Node ${process.version}, esbuild ${esbuildVersion}`);
  console.error(`[Clash IQ] API source: ${path.resolve(artifactDir, "src/index.ts")}`);

  await rm(distDir, { recursive: true, force: true });

  await esbuild({
    entryPoints: [path.resolve(artifactDir, "src/index.ts")],
    platform: "node",
    bundle: true,
    format: "esm",
    outdir: distDir,
    outExtension: { ".js": ".mjs" },
    logLevel: "info",
    external: [
      "*.node","sharp","better-sqlite3","sqlite3","canvas","bcrypt","argon2","fsevents","re2",
      "farmhash","xxhash-addon","bufferutil","utf-8-validate","ssh2","cpu-features","dtrace-provider",
      "isolated-vm","lightningcss","pg-native","oracledb","mongodb-client-encryption","nodemailer",
      "handlebars","knex","typeorm","protobufjs","onnxruntime-node","@tensorflow/*","@prisma/client",
      "@mikro-orm/*","@grpc/*","@swc/*","@aws-sdk/*","@azure/*","@opentelemetry/*","@google-cloud/*",
      "@google/*","googleapis","firebase-admin","@parcel/watcher","@sentry/profiling-node","@tree-sitter/*",
      "aws-sdk","classic-level","dd-trace","ffi-napi","grpc","hiredis","kerberos","leveldown","miniflare",
      "mysql2","newrelic","odbc","piscina","realm","ref-napi","rocksdb","sass-embedded","sequelize",
      "serialport","snappy","tinypool","usb","workerd","wrangler","zeromq","zeromq-prebuilt",
      "playwright","puppeteer","puppeteer-core","electron"
    ],
    sourcemap: "linked",
    banner: {
      js: `import { createRequire as __bannerCrReq } from 'node:module';
import __bannerPath from 'node:path';
import __bannerUrl from 'node:url';

globalThis.require = __bannerCrReq(import.meta.url);
globalThis.__filename = __bannerUrl.fileURLToPath(import.meta.url);
globalThis.__dirname = __bannerPath.dirname(globalThis.__filename);
      `,
    },
  });

  console.error("[Clash IQ] API build completed successfully.");
}

buildAll().catch((err) => {
  console.error("[Clash IQ] API BUILD FAILED");
  console.error("name:", err?.name);
  console.error("message:", err?.message);
  console.error("stack:", err?.stack);
  console.error("errors:", err?.errors);
  console.error("warnings:", err?.warnings);
  console.error(err);
  process.exit(1);
});
