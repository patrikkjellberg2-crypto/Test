# Bygga Android-app (APK & AAB)

Dashboarden är nu förberedd som en [Capacitor](https://capacitorjs.com/)-app. Själva
bygget sker i GitHub Actions (`.github/workflows/android-build.yml`), eftersom det
kräver Android SDK och nätverksåtkomst som inte finns i den här utvecklingsmiljön.

## Engångsinställning i GitHub

1. **Pusha det här projektet till ett GitHub-repo** (om det inte redan ligger där).
2. Gå till **Settings → Secrets and variables → Actions** i repot och lägg till:

   **Secrets** (hemliga):
   - `ANDROID_KEYSTORE_BASE64` — innehållet i `keystore-base64.txt` (den bifogade filen)
   - `ANDROID_KEYSTORE_PASSWORD` — se `credentials.txt`
   - `ANDROID_KEY_ALIAS` — `mecka-clash`
   - `ANDROID_KEY_PASSWORD` — samma värde som `ANDROID_KEYSTORE_PASSWORD`

   **Variables** (icke-hemliga):
   - `VITE_API_BASE_URL` — den publika URL:en där API-servern är driftsatt,
     t.ex. `https://mecka-clash.up.railway.app`

3. **Spara `mecka-clash-release.keystore` och `credentials.txt` någon säkert**
   (t.ex. en lösenordshanterare). Detta ÄR din app-signeringsnyckel — om du
   tappar bort den kan du aldrig mer släppa en uppdatering till samma
   Play Store-listning. Lägg ALDRIG filerna i git.

## Köra bygget

- Workflown körs automatiskt vid push till `main` som rör dashboarden, eller
  manuellt via **Actions → Build Android APK & AAB → Run workflow**.
- När den är klar hittar du två nedladdningsbara artefakter under körningen:
  - `app-debug-apk` — för att testa direkt på en Android-telefon (installera
    via `adb install` eller genom att flytta filen till telefonen)
  - `app-release-aab` — den signerade filen du laddar upp till
    **Google Play Console**

## Justera app-identitet

- `artifacts/mecka-clash-dashboard/capacitor.config.ts` — `appId` (paketnamn,
  permanent efter första Play Store-releasen) och `appName`
- App-ikon: kör `pnpm exec @capacitor/assets generate` lokalt (kräver
  nätverk) med en 1024×1024 ikonfil, eller lägg ikoner manuellt i
  `android/app/src/main/res/` efter första `cap add android`

## Lokal testkörning (om du har Android Studio)

```bash
cd artifacts/mecka-clash-dashboard
pnpm install
pnpm run build
pnpm exec cap add android   # första gången
pnpm exec cap sync android
pnpm exec cap open android  # öppnar Android Studio
```
