import type { CapacitorConfig } from '@capacitor/cli';

// EDIT ME: reverse-DNS app id. Once you publish to Google Play this value
// is permanent for that app listing, so pick it before your first release.
const appId = 'com.meckaclash.dashboard';

const config: CapacitorConfig = {
  appId,
  appName: 'Mecka Clash',
  // Capacitor bundles the built web assets (dist/public) into the app.
  // The app still talks to your real API over the network at runtime —
  // see src/main.tsx (VITE_API_BASE_URL) for how that's wired up.
  webDir: 'dist/public',
  server: {
    androidScheme: 'https',
  },
};

export default config;
