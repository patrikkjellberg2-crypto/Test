import { type ReactNode } from 'react';
import { useLocation } from 'wouter';

const BANNER_SRC = '/clash-iq-war-banner.png';

export function ClashIQPageBanner({ children }: { children: ReactNode }) {
  const [location] = useLocation();

  // Overview keeps its existing hero. Every other route gets one shared banner.
  if (location === '/') return <>{children}</>;

  return (
    <div className="clashiq-global-banner-page relative min-h-[100dvh] bg-[#07090d]">
      <style>{`
        .clashiq-global-banner-page main {
          padding-top: 220px !important;
        }

        @media (min-width: 1024px) {
          .clashiq-global-banner-page main {
            padding-top: 250px !important;
          }
        }

        /* Hide old page-specific banner blocks. The shared banner above is the only banner. */
        .clashiq-global-banner-page main > *:has(img[alt="Clash IQ"]),
        .clashiq-global-banner-page main > *:has(img[alt^="Clash IQ —"]),
        .clashiq-global-banner-page main > *:has(img[alt="Clash IQ — Plan, Analyze, Improve, Win"]) {
          display: none !important;
        }
      `}</style>

      <div className="pointer-events-none absolute left-0 right-0 top-0 z-30 h-[220px] overflow-hidden lg:left-[260px] lg:h-[250px]">
        <img
          src={BANNER_SRC}
          alt="Clash IQ global banner"
          className="block h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-[#07090d]" />
      </div>

      {children}
    </div>
  );
}
