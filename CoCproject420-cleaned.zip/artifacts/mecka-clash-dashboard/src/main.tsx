import { createRoot } from 'react-dom/client';

import App from './App';
import { ErrorBoundary } from '@/components/error-boundary';

import './index.css';

// When running inside the Capacitor Android/iOS shell, the app is served
// from a local origin (capacitor://localhost), so relative API calls must
// be pointed at the real backend explicitly. VITE_API_BASE_URL is baked in
// at build time (see .env.production / the Android build workflow).
if (import.meta.env.VITE_API_BASE_URL) {
  const { setBaseUrl } = await import('@workspace/api-client-react');
  setBaseUrl(import.meta.env.VITE_API_BASE_URL);
}

createRoot(document.getElementById('root')!, {
  // Keeps caught errors off reportError(), which would raise the dev overlay.
  onCaughtError: (error, errorInfo) => {
    console.error(error, errorInfo.componentStack);
  },
}).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>,
);
