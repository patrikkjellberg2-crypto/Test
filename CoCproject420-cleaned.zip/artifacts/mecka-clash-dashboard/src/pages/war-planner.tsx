import { memo, useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  ArrowLeft,
  Brain,
  Check,
  Copy,
  CheckCheck,
  ChevronDown,
  Clock3,
  Lock,
  LockOpen,
  Menu,
  RefreshCw,
  Shield,
  ShieldAlert,
  Sparkles,
  Swords,
  Target,
  Users,
  X,
} from 'lucide-react';

import {
  getGetWarPlannerQueryKey,
  useGetClashDashboard,
  useGetWarPlanner,
} from '@workspace/api-client-react';

import { Link } from 'wouter';

import { MemberDetailsDialog } from '@/components/member-details-dialog';
import { AppSidebar } from '@/components/app-sidebar';

const CLASH_IQ_MENU_BANNER = '/images/war-planner-banner.jpg';

/* =========================================================
   TYPES
========================================================= */

type Dict = Record<string, unknown>;

type Assignment = {
  warKey: string;
  attacksTag: string;
  assignedTargetMapPosition: number | null;
  locked: boolean;
  completed: boolean;
  updatedAt?: string;
};

type AIRecommendation = {
  attackerTag: string;
  attackerName: string;
  attackerTownhall: number;
  attackerPosition: number;
  targetPosition: number;
  targetName: string;
  targetTownhall: number;
  score: number;
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  purpose?:
    | '3-star attempt'
    | 'safe 2-star'
    | 'cleanup';
  reason: string;
};

type AIPlan = {
  warStatus: 'WINNING' | 'CLOSE' | 'LOSING';
  summary: string;
  recommendations: AIRecommendation[];
  notes: string[];
};

/* =========================================================
   HELPERS
========================================================= */

function asDict(value: unknown): Dict {
  return value && typeof value === 'object'
    ? (value as Dict)
    : {};
}

function asArray(value: unknown): Dict[] {
  return Array.isArray(value)
    ? value.map(asDict)
    : [];
}

function str(
  value: unknown,
  fallback = '',
): string {
  return typeof value === 'string'
    ? value
    : fallback;
}

function num(
  value: unknown,
  fallback = 0,
): number {
  if (
    typeof value === 'number' &&
    Number.isFinite(value)
  ) {
    return value;
  }

  if (typeof value === 'string') {
    const parsed = Number(value);

    return Number.isFinite(parsed)
      ? parsed
      : fallback;
  }

  return fallback;
}

function label(
  value: unknown,
  fallback = '—',
): string {
  return str(value, fallback);
}

function initials(name: string): string {
  return (
    name
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) =>
        part.charAt(0),
      )
      .join('')
      .toUpperCase() || 'MC'
  );
}

function normalizeWarState(
  value: unknown,
): string {
  const state = str(value)
    .trim()
    .toLowerCase();

  if (
    state === 'inwar' ||
    state === 'in_war'
  ) {
    return 'inwar';
  }

  if (
    state === 'preparation' ||
    state === 'preparing'
  ) {
    return 'preparation';
  }

  if (
    state === 'warended' ||
    state === 'war_ended' ||
    state === 'ended'
  ) {
    return 'warended';
  }

  if (state === 'matchmaking') {
    return 'matchmaking';
  }

  return state;
}

function getWarStart(
  currentWar: Dict,
): string {
  return (
    str(currentWar.startTime) ||
    str(currentWar.prepStartTime) ||
    str(currentWar.preparationStartTime)
  );
}

function getWarEnd(
  currentWar: Dict,
): string {
  return (
    str(currentWar.endTime) ||
    str(currentWar.warEndTime)
  );
}

/* =========================================================
   CLASH TIME PARSER
========================================================= */

const CLASH_WAR_DAY_MS =
  24 * 60 * 60 * 1000;

function parseTime(
  value: unknown,
): number | null {
  if (
    typeof value === 'number' &&
    Number.isFinite(value)
  ) {
    return value < 100000000000
      ? value * 1000
      : value;
  }

  const raw = str(value).trim();

  if (!raw) {
    return null;
  }

  const clashMatch = raw.match(
    /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(?:\.(\d+))?Z?$/,
  );

  if (clashMatch) {
    const [
      ,
      year,
      month,
      day,
      hour,
      minute,
      second,
      fraction,
    ] = clashMatch;

    const milliseconds = fraction
      ? Number(
          fraction
            .slice(0, 3)
            .padEnd(3, '0'),
        )
      : 0;

    const timestamp = Date.UTC(
      Number(year),
      Number(month) - 1,
      Number(day),
      Number(hour),
      Number(minute),
      Number(second),
      milliseconds,
    );

    return Number.isFinite(timestamp)
      ? timestamp
      : null;
  }

  const timestamp =
    new Date(raw).getTime();

  return Number.isFinite(timestamp)
    ? timestamp
    : null;
}

/* =========================================================
   WAR TIME FALLBACKS
========================================================= */

function getWarStartTimestamp(
  currentWar: Dict,
): number | null {
  const directStart =
    parseTime(
      currentWar.startTime,
    ) ??
    parseTime(
      currentWar.warStartTime,
    );

  if (directStart !== null) {
    return directStart;
  }

  const preparationStart =
    parseTime(
      currentWar.preparationStartTime,
    ) ??
    parseTime(
      currentWar.prepStartTime,
    );

  if (
    preparationStart !== null
  ) {
    return (
      preparationStart +
      CLASH_WAR_DAY_MS
    );
  }

  return null;
}

function getWarEndTimestamp(
  currentWar: Dict,
): number | null {
  const directEnd =
    parseTime(
      currentWar.endTime,
    ) ??
    parseTime(
      currentWar.warEndTime,
    );

  if (directEnd !== null) {
    return directEnd;
  }

  const warStart =
    getWarStartTimestamp(
      currentWar,
    );

  if (warStart !== null) {
    return (
      warStart +
      CLASH_WAR_DAY_MS
    );
  }

  return null;
}

function formatCountdown(
  milliseconds: number,
): string {
  if (
    !Number.isFinite(milliseconds)
  ) {
    return 'NO TIMER';
  }

  if (milliseconds <= 0) {
    return '00:00:00';
  }

  const totalSeconds =
    Math.floor(
      milliseconds / 1000,
    );

  const days =
    Math.floor(
      totalSeconds / 86400,
    );

  const hours =
    Math.floor(
      (totalSeconds % 86400) /
        3600,
    );

  const minutes =
    Math.floor(
      (totalSeconds % 3600) /
        60,
    );

  const seconds =
    totalSeconds % 60;

  const hh = String(hours)
    .padStart(2, '0');

  const mm = String(minutes)
    .padStart(2, '0');

  const ss = String(seconds)
    .padStart(2, '0');

  if (days > 0) {
    return `${days}d ${hh}:${mm}:${ss}`;
  }

  return `${hh}:${mm}:${ss}`;
}

/* =========================================================
   BRAND
========================================================= */

function SwedishMark({
  small = false,
}: {
  small?: boolean;
}) {
  return (
    <div
      className={`relative grid shrink-0 place-items-center overflow-hidden rounded-xl bg-[#f4c542] text-[#0b2b45] ${
        small ? 'size-9' : 'size-11'
      }`}
    >
      <span className="absolute left-[35%] top-0 h-full w-[16%] bg-[#0b5fa5]" />

      <span className="absolute left-0 top-[38%] h-[16%] w-full bg-[#0b5fa5]" />

      <Shield
        className={
          small
            ? 'relative z-10 size-4'
            : 'relative z-10 size-5'
        }
      />
    </div>
  );
}

/* =========================================================
   STATUS
========================================================= */

function StatusPill({
  label,
  tone = 'neutral',
}: {
  label: string;
  tone?:
    | 'success'
    | 'info'
    | 'warning'
    | 'danger'
    | 'neutral';
}) {
  const classes =
    tone === 'success'
      ? 'bg-[#2b9f78]/12 text-[#267a5e]'
      : tone === 'info'
        ? 'bg-primary/10 text-primary'
        : tone === 'warning'
          ? 'bg-[#f4c542]/20 text-[#9c6e00]'
          : tone === 'danger'
            ? 'bg-destructive/10 text-destructive'
            : 'bg-secondary text-muted-foreground';

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-[.1em] ${classes}`}
    >
      {label}
    </span>
  );
}

/* =========================================================
   SIDEBAR
========================================================= */

function DesktopSidebar() {
  return (
    <aside
      className="
        relative
        z-40
        hidden
        h-[100dvh]
        w-[260px]
        shrink-0
        bg-sidebar
        lg:block
      "
    >
      <div className="h-full overflow-y-auto">
        <AppSidebar />
      </div>
    </aside>
  );
}

/* =========================================================
   MOBILE SIDEBAR
========================================================= */

function MobileSidebar({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  if (!open) {
    return null;
  }

  const navItems = [
    {
      href: '/war-center',
      label: 'War Center',
      icon: Swords,
    },
    {
      href: '/war-planner',
      label: 'War Planner',
      icon: Target,
    },
    {
      href: '/capital-raids',
      label: 'Capital Raids',
      icon: Shield,
    },
    {
      href: '/members',
      label: 'Members',
      icon: Users,
    },
  ];

  return (
    <div className="fixed inset-0 z-[100] lg:hidden">
      <button
        type="button"
        aria-label="Close menu"
        className="absolute inset-0 bg-black/60 backdrop-blur-[2px]"
        onClick={onClose}
      />

      <aside
        className="
          relative
          z-[101]
          flex
          h-[100dvh]
          w-[300px]
          max-w-[86vw]
          flex-col
          overflow-y-auto
          border-r
          border-sidebar-border
          bg-sidebar
          shadow-2xl
        "
      >
        {/* MOBILE MENU HEADER */}
        <div className="flex shrink-0 items-center justify-between border-b border-sidebar-border p-4">
          <div className="flex items-center gap-3">
            <SwedishMark small />

            <div>
              <p className="font-display text-sm font-black text-sidebar-foreground">
                MECKA CLASH
              </p>

              <p className="text-[9px] font-bold uppercase tracking-[.16em] text-sidebar-foreground/50">
                WAR PLANNER
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close menu"
            className="grid size-10 place-items-center rounded-xl text-sidebar-foreground/70 transition hover:bg-sidebar-accent hover:text-sidebar-foreground"
          >
            <X className="size-5" />
          </button>
        </div>

        {/* MOBILE NAVIGATION */}
        <nav className="flex-1 p-3">
          <p className="px-3 pb-2 pt-2 text-[9px] font-black uppercase tracking-[.18em] text-sidebar-foreground/40">
            Navigation
          </p>

          <div className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={onClose}
                  className="
                    flex
                    min-h-12
                    items-center
                    gap-3
                    rounded-xl
                    px-3
                    text-sm
                    font-bold
                    text-sidebar-foreground/75
                    transition
                    hover:bg-sidebar-accent
                    hover:text-sidebar-foreground
                  "
                >
                  <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-sidebar-accent/60">
                    <Icon className="size-4" />
                  </span>

                  <span>{item.label}</span>
                </Link>
              );
            })}
          </div>
        </nav>

        {/* MOBILE BRAND FOOTER */}
        <div className="shrink-0 border-t border-sidebar-border p-4">
          <div className="rounded-2xl border border-sidebar-border bg-sidebar-accent/30 p-4">
            <p className="font-display text-xs font-black tracking-wide text-sidebar-foreground">
              MECKA CLASH
            </p>

            <p className="mt-1 text-[9px] font-bold uppercase tracking-[.16em] text-sidebar-foreground/40">
              Plan · Attack · Improve · Repeat
            </p>
          </div>
        </div>
      </aside>
    </div>
  );
}

/* =========================================================
   LOADING
========================================================= */

function LoadingState() {
  return (
    <div className="min-h-[100dvh] bg-background dashboard-grid">
      <div className="flex min-h-[100dvh]">
        <DesktopSidebar />

        <main className="min-w-0 flex-1 p-5 md:p-8">
          <div className="mx-auto max-w-[1400px]">
            <div className="h-8 w-52 animate-pulse rounded bg-muted" />

            <div className="mt-8 h-52 animate-pulse rounded-3xl bg-muted" />

            <div className="mt-5 space-y-3">
              {[1, 2, 3, 4, 5].map(
                (item) => (
                  <div
                    key={item}
                    className="h-24 animate-pulse rounded-2xl bg-muted"
                  />
                ),
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

/* =========================================================
   ERROR
========================================================= */

function ErrorState({
  onRetry,
}: {
  onRetry: () => void;
}) {
  return (
    <div className="grid min-h-[100dvh] place-items-center bg-background p-6 dashboard-grid">
      <section className="w-full max-w-[520px] rounded-3xl border border-destructive/30 bg-card p-8 text-center shadow-lg">
        <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-destructive/10 text-destructive">
          <ShieldAlert className="size-6" />
        </div>

        <h1 className="mt-5 font-display text-2xl font-bold">
          Could not load the war
        </h1>

        <p className="mt-2 text-sm text-muted-foreground">
          War data could not be loaded.
        </p>

        <button
          type="button"
          onClick={onRetry}
          className="mt-6 inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-bold text-primary-foreground"
        >
          <RefreshCw className="size-4" />
          Try again
        </button>
      </section>
    </div>
  );
}

/* =========================================================
   EMPTY WAR
========================================================= */

function EmptyWarState() {
  return (
    <div className="grid min-h-[100dvh] bg-background dashboard-grid lg:grid-cols-[260px_minmax(0,1fr)]">
      <DesktopSidebar />

      <main className="grid min-h-[100dvh] place-items-center p-6">
        <section className="w-full max-w-[560px] rounded-3xl border border-border bg-card p-8 text-center shadow-lg">
          <div className="mx-auto grid size-16 place-items-center rounded-2xl bg-secondary text-muted-foreground">
            <Swords className="size-7" />
          </div>

          <p className="mt-6 text-[11px] font-bold uppercase tracking-[.18em] text-primary">
            Mecka Clash / War Planner
          </p>

          <h1 className="mt-3 font-display text-3xl font-bold">
            No active war right now
          </h1>

          <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-muted-foreground">
            When the next war starts, you can plan and assign attacks here.
          </p>

          <Link
            href="/war-center"
            className="mt-7 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
          >
            <ArrowLeft className="size-4" />
            Back to War Center
          </Link>
        </section>
      </main>
    </div>
  );
}

/* =========================================================
   AI RECOMMENDATION CARD
========================================================= */

function RecommendationCard({
  recommendation,
}: {
  recommendation: AIRecommendation;
}) {
  const confidenceClass =
    recommendation.confidence === 'HIGH'
      ? 'bg-[#2b9f78]/12 text-[#267a5e]'
      : recommendation.confidence ===
          'MEDIUM'
        ? 'bg-[#f4c542]/20 text-[#9c6e00]'
        : 'bg-secondary text-muted-foreground';

  return (
    <div className="rounded-2xl border border-primary/15 bg-background/60 p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
            <Target className="size-4" />
          </div>

          <div className="min-w-0">
            <p className="truncate text-sm font-black">
              {recommendation.attackerName}
            </p>

            <p className="text-[10px] text-muted-foreground">
              TH{recommendation.attackerTownhall}
              {' · #'}
              {recommendation.attackerPosition}
              {' → #'}
              {recommendation.targetPosition}
            </p>
          </div>
        </div>

        <span
          className={`rounded-full px-2 py-1 text-[9px] font-black uppercase tracking-[.1em] ${confidenceClass}`}
        >
          {recommendation.confidence}
        </span>
      </div>

      <div className="mt-3 flex items-center gap-3">
        <div className="grid size-9 place-items-center rounded-lg bg-secondary font-data text-xs font-black">
          #{recommendation.attackerPosition}
        </div>

        <div className="h-px flex-1 bg-border" />

        <div className="rounded-xl bg-primary px-3 py-2 text-center text-primary-foreground">
          <p className="text-[8px] font-black uppercase tracking-[.1em]">
            Target
          </p>

          <p className="font-data text-lg font-black">
            #{recommendation.targetPosition}
          </p>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {recommendation.purpose && (
          <span className="rounded-full bg-primary/10 px-2 py-1 text-[9px] font-black text-primary">
            {recommendation.purpose}
          </span>
        )}

        <span className="rounded-full bg-secondary px-2 py-1 font-data text-[9px] font-black text-muted-foreground">
          Score {recommendation.score}
        </span>
      </div>

      <p className="mt-3 text-[10px] leading-4 text-muted-foreground">
        {recommendation.reason}
      </p>
    </div>
  );
}

/* =========================================================
   PLANNER ROW
========================================================= */

const PlannerRow = memo(function PlannerRow({
  member,
  assignment,
  opponents,
  pending,
  onAssign,
  onToggleLock,
  onComplete,
  onUndo,
  onOpenMember,
  onGenerateMessage,
}: {
  member: Dict;
  assignment: Assignment;
  opponents: Dict[];
  pending: boolean;
  onAssign: (
    target: number | null,
  ) => void;
  onToggleLock: () => void;
  onComplete: () => void;
  onUndo: () => void;
  onOpenMember: () => void;
  onGenerateMessage: () => void;
}) {
  const tag =
    str(member.tag) || 'unknown';

  const name =
    label(
      member.name,
      'Unknown member',
    );

  const position =
    num(member.mapPosition);

  const townHall =
    num(
      member.townhallLevel,
      num(
        member.townHallLevel,
      ),
    );

  const attacks =
    asArray(member.attacks);

  const attacksUsed =
    attacks.length;

  const attacksRemaining =
    Math.max(
      2 - attacksUsed,
      0,
    );

  const assignedTarget =
    opponents.find(
      (candidate) =>
        num(
          candidate.mapPosition,
        ) ===
        assignment.assignedTargetMapPosition,
    );

  return (
    <article
      className={`border-b border-border p-4 last:border-b-0 md:p-5 ${
        assignment.completed
          ? 'bg-[#2b9f78]/[0.035]'
          : ''
      }`}
    >
      <div className="flex flex-col gap-4 xl:flex-row xl:items-center">
        <button
          type="button"
          onClick={onOpenMember}
          className="flex min-w-0 items-center gap-3 text-left xl:w-[280px]"
        >
          <div
            className={`grid size-11 shrink-0 place-items-center rounded-xl text-xs font-black ${
              assignment.completed
                ? 'bg-[#2b9f78]/12 text-[#267a5e]'
                : 'bg-primary/10 text-primary'
            }`}
          >
            {assignment.completed ? (
              <Check className="size-4" />
            ) : (
              initials(name)
            )}
          </div>

          <div className="min-w-0">
            <p className="truncate text-sm font-bold hover:text-primary">
              {name}
            </p>

            <p className="mt-1 font-data text-[11px] text-muted-foreground">
              TH {townHall}
              {' · #'}
              {position}
            </p>

            <div className="mt-1 flex gap-1.5">
              <span className="rounded-full bg-secondary px-2 py-1 text-[9px] font-black text-muted-foreground">
                {attacksUsed}/2
              </span>

              <span className="rounded-full bg-primary/10 px-2 py-1 text-[9px] font-black text-primary">
                {attacksRemaining} kvar
              </span>
            </div>
          </div>
        </button>

        <div className="flex min-w-0 flex-1 items-center gap-3">
          <div className="w-full max-w-[400px]">
            <label className="relative block">
              <span className="sr-only">
                Target
              </span>

              <select
                value={
                  assignment.assignedTargetMapPosition ===
                  null
                    ? ''
                    : String(
                        assignment.assignedTargetMapPosition,
                      )
                }
                onChange={(event) =>
                  onAssign(
                    event.target.value
                      ? Number(
                          event.target.value,
                        )
                      : null,
                  )
                }
                disabled={
                  pending ||
                  assignment.locked ||
                  assignment.completed ||
                  attacksRemaining <= 0
                }
                className="h-11 w-full appearance-none rounded-xl border border-border bg-background px-3 pr-10 text-sm font-bold outline-none focus:border-primary disabled:cursor-not-allowed disabled:opacity-50"
              >
                <option value="">
                  Select target…
                </option>

                {opponents.map(
                  (opponent) => {
                    const targetPosition =
                      num(
                        opponent.mapPosition,
                      );

                    const targetTH =
                      num(
                        opponent.townhallLevel,
                        num(
                          opponent.townHallLevel,
                        ),
                      );

                    return (
                      <option
                        key={`${tag}-${targetPosition}`}
                        value={targetPosition}
                      >
                        #{targetPosition}
                        {' · TH'}
                        {targetTH}
                        {' · '}
                        {label(
                          opponent.name,
                          'Unknown',
                        )}
                      </option>
                    );
                  },
                )}
              </select>

              <ChevronDown className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            </label>

            {assignedTarget && (
              <p className="mt-1.5 text-[10px] font-bold text-primary">
                Assigned: #
                {num(
                  assignedTarget.mapPosition,
                )}
                {' · '}
                {label(
                  assignedTarget.name,
                )}
              </p>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 xl:justify-end">
          {assignment.completed ? (
            <StatusPill
              label="Complete"
              tone="success"
            />
          ) : assignment.locked ? (
            <StatusPill
              label="Locked"
              tone="info"
            />
          ) : (
            <StatusPill
              label="Needs attack"
              tone="warning"
            />
          )}

          <button
            type="button"
            onClick={onToggleLock}
            disabled={
              pending ||
              (
                !assignment.locked &&
                (
                  assignment.assignedTargetMapPosition ===
                    null ||
                  assignment.completed
                )
              )
            }
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-border px-3 text-xs font-bold disabled:cursor-not-allowed disabled:opacity-40"
          >
            {assignment.locked ? (
              <LockOpen className="size-3.5" />
            ) : (
              <Lock className="size-3.5" />
            )}

            {assignment.locked
              ? 'Unlock'
              : 'Lock'}
          </button>

          {(assignment.assignedTargetMapPosition !==
            null ||
            assignment.locked ||
            assignment.completed) && (
            <button
              type="button"
              onClick={onUndo}
              disabled={pending}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-destructive/30 bg-destructive/5 px-3 text-xs font-bold text-destructive disabled:opacity-40"
            >
              <ArrowLeft className="size-3.5" />
              Undo
            </button>
          )}

          {assignment.assignedTargetMapPosition !== null && (
            <button
              type="button"
              onClick={onGenerateMessage}
              disabled={pending}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-amber-400/30 bg-amber-400/10 px-3 text-xs font-black text-amber-300 transition hover:bg-amber-400/15 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Copy className="size-3.5" />
              Generate Message
            </button>
          )}

          <button
            type="button"
            onClick={onComplete}
            disabled={
              pending ||
              assignment.completed ||
              assignment.assignedTargetMapPosition ===
                null
            }
            className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-primary px-3 text-xs font-bold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-40"
          >
            {pending ? (
              <RefreshCw className="size-3.5 animate-spin" />
            ) : (
              <Check className="size-3.5" />
            )}

            Complete
          </button>
        </div>
      </div>
    </article>
  );
});

/* =========================================================
   OPPONENT ATTACK HISTORY
========================================================= */

function OpponentAttackHistory({
  opponents,
  ourMembers,
}: {
  opponents: Dict[];
  ourMembers: Dict[];
}) {
  const ourByTag = useMemo(() => {
    const map = new Map<string, Dict>();

    ourMembers.forEach((member) => {
      const tag = str(member.tag).toUpperCase();
      if (tag) map.set(tag, member);
    });

    return map;
  }, [ourMembers]);

  const rows = useMemo(() => {
    return opponents.map((opponent) => {
      const attacks = asArray(opponent.attacks)
        .map((attack) => {
          const defenderTag = str(
            attack.defenderTag ??
              attack.defender?.tag ??
              attack.targetTag,
          ).toUpperCase();

          const defender =
            ourByTag.get(defenderTag) ??
            ourMembers.find(
              (member) =>
                num(member.mapPosition) ===
                num(
                  attack.defenderMapPosition ??
                    attack.targetMapPosition ??
                    attack.defenderPosition,
                ),
            );

          return { attack, defender };
        })
        .filter(({ attack }) => Object.keys(attack).length > 0);

      return { opponent, attacks };
    });
  }, [opponents, ourMembers, ourByTag]);

  const totalUsed = rows.reduce(
    (sum, row) => sum + row.attacks.length,
    0,
  );
  const totalAvailable = opponents.length * 2;
  const totalRemaining = Math.max(0, totalAvailable - totalUsed);
  const attackersUsed = rows.filter((row) => row.attacks.length > 0).length;
  const attackersRemaining = Math.max(
    0,
    opponents.length - attackersUsed,
  );
  const totalThreeStars = rows.reduce(
    (sum, row) =>
      sum +
      row.attacks.filter(
        ({ attack }) => num(attack.stars) === 3,
      ).length,
    0,
  );

  return (
    <section className="mb-6 overflow-hidden rounded-3xl border border-border bg-card shadow-sm">
      <div className="border-b border-border bg-gradient-to-r from-destructive/10 via-card to-card p-5 md:p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Swords className="size-5 text-destructive" />
              <h2 className="font-display text-xl font-black uppercase">
                OPPONENT ATTACK INTELLIGENCE
              </h2>
            </div>
            <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
              Track every opponent attack, the base they targeted, and the result so the remaining war can be planned around what has already happened.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:min-w-[430px]">
            <div className="rounded-2xl border border-border bg-background/50 p-3">
              <p className="text-[9px] font-black uppercase tracking-[.14em] text-muted-foreground">
                Attacks used
              </p>
              <p className="mt-1 font-data text-lg font-black">
                {totalUsed}/{totalAvailable}
              </p>
            </div>
            <div className="rounded-2xl border border-border bg-background/50 p-3">
              <p className="text-[9px] font-black uppercase tracking-[.14em] text-muted-foreground">
                Remaining
              </p>
              <p className="mt-1 font-data text-lg font-black">
                {totalRemaining}
              </p>
            </div>
            <div className="rounded-2xl border border-border bg-background/50 p-3">
              <p className="text-[9px] font-black uppercase tracking-[.14em] text-muted-foreground">
                Players left
              </p>
              <p className="mt-1 font-data text-lg font-black">
                {attackersRemaining}
              </p>
            </div>
            <div className="rounded-2xl border border-border bg-background/50 p-3">
              <p className="text-[9px] font-black uppercase tracking-[.14em] text-muted-foreground">
                Three-stars
              </p>
              <p className="mt-1 font-data text-lg font-black">
                {totalThreeStars}
              </p>
            </div>
          </div>
        </div>
      </div>

      {rows.length === 0 ? (
        <div className="p-8 text-center">
          <Swords className="mx-auto size-10 text-muted-foreground/40" />
          <p className="mt-3 font-bold">No opponent attacks yet</p>
          <p className="mx-auto mt-1 max-w-lg text-sm text-muted-foreground">
            Opponent attacks will appear here automatically when they are recorded in the current war.
          </p>
        </div>
      ) : (
        <div className="divide-y divide-border">
          {rows.map(({ opponent, attacks }) => {
            const opponentName = label(opponent.name, 'Unknown player');
            const opponentPosition = num(opponent.mapPosition);
            const opponentTH = num(
              opponent.townhallLevel,
              num(opponent.townHallLevel),
            );
            const attacksRemaining = Math.max(0, 2 - attacks.length);

            return (
              <article
                key={str(opponent.tag) || `${opponentPosition}-${opponentName}`}
                className="p-4 md:p-5"
              >
                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="grid size-11 shrink-0 place-items-center rounded-xl bg-destructive/10 text-sm font-black text-destructive">
                      #{opponentPosition}
                    </div>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-black">{opponentName}</p>
                      <p className="mt-1 font-data text-[11px] text-muted-foreground">
                        TH{opponentTH} · {attacks.length}/2 attacks used
                      </p>
                      {attacksRemaining > 0 ? (
                        <p className="mt-1 text-[10px] font-bold text-amber-500">
                          {attacksRemaining} attack remaining
                        </p>
                      ) : (
                        <p className="mt-1 text-[10px] font-bold text-muted-foreground">
                          All attacks used
                        </p>
                      )}
                    </div>
                  </div>

                  {attacks.length > 0 ? (
                    <div className="grid w-full gap-2 md:grid-cols-2 lg:max-w-[620px]">
                      {attacks.map(({ attack, defender }, index) => {
                        const stars = num(attack.stars);
                        const destruction = num(
                          attack.destructionPercentage ??
                            attack.destructionPercent,
                        );
                        const defenderPosition = num(
                          defender?.mapPosition ??
                            attack.defenderMapPosition ??
                            attack.targetMapPosition ??
                            attack.defenderPosition,
                        );
                        const defenderName = label(
                          defender?.name ?? attack.defenderName,
                          defenderPosition
                            ? `Our Base #${defenderPosition}`
                            : 'Our Base',
                        );

                        return (
                          <div
                            key={`${str(opponent.tag)}-${index}-${defenderPosition}`}
                            className="rounded-2xl border border-border bg-background/60 p-3"
                          >
                            <div className="flex items-center justify-between gap-3">
                              <span className="text-[9px] font-black uppercase tracking-[.14em] text-muted-foreground">
                                Attack {index + 1}
                              </span>
                              <span className="font-data text-sm font-black">
                                {'⭐'.repeat(Math.max(0, Math.min(3, stars)))}
                                {stars === 0 ? '—' : ''}
                              </span>
                            </div>

                            <div className="mt-2 flex items-center gap-2">
                              <div className="rounded-lg bg-destructive/10 px-2 py-1 font-data text-xs font-black text-destructive">
                                #{opponentPosition}
                              </div>
                              <div className="h-px flex-1 bg-border" />
                              <div className="rounded-lg bg-secondary px-2 py-1 font-data text-xs font-black">
                                #{defenderPosition || '?'}
                              </div>
                            </div>

                            <p className="mt-2 truncate text-xs font-bold">
                              {opponentName} → {defenderName}
                            </p>
                            <p className="mt-1 font-data text-[10px] text-muted-foreground">
                              {stars}/3 stars · {destruction}% destruction
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="flex w-full items-center rounded-2xl border border-dashed border-amber-500/30 bg-amber-500/5 p-4 lg:max-w-[620px]">
                      <div>
                        <p className="text-sm font-black">No attacks used yet</p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          This player still has 2 attacks available.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}

/* =========================================================
   MAIN PAGE
========================================================= */

const CLASH_IQ_BANNER = '/images/war-planner-banner-2.webp';
export default function WarPlannerPage() {
  const queryClient =
    useQueryClient();

  const {
    data,
    isLoading,
    isError,
    refetch,
  } =
    useGetClashDashboard();

  const dashboard =
    asDict(data);

  const currentWar =
    asDict(
      dashboard.currentWar,
    );

  const clan =
    asDict(
      currentWar.clan,
    );

  const opponent =
    asDict(
      currentWar.opponent,
    );

  const clanMembers =
    useMemo(
      () =>
        asArray(
          clan.members,
        ).sort(
          (a, b) =>
            num(
              a.mapPosition,
              999,
            ) -
            num(
              b.mapPosition,
              999,
            ),
        ),
      [clan.members],
    );

  const opponentMembers =
    useMemo(
      () =>
        asArray(
          opponent.members,
        ).sort(
          (a, b) =>
            num(
              a.mapPosition,
              999,
            ) -
            num(
              b.mapPosition,
              999,
            ),
        ),
      [opponent.members],
    );

  /* =======================================================
     WAR KEY
  ======================================================= */

  const warKey =
    useMemo(() => {
      const parts = [
        getWarStart(currentWar),
        getWarEnd(currentWar),
      ].filter(Boolean);

      return parts.length
        ? `war:${parts.join('|')}`
        : '';
    }, [
      currentWar.startTime,
      currentWar.prepStartTime,
      currentWar.preparationStartTime,
      currentWar.endTime,
      currentWar.warEndTime,
    ]);

  const plannerQuery =
    useGetWarPlanner(
      {
        warKey:
          warKey ||
          'pending-war',
      },
      {
        query: {
          enabled:
            Boolean(warKey),

          queryKey:
            getGetWarPlannerQueryKey(
              {
                warKey:
                  warKey ||
                  'pending-war',
              },
            ),
        },
      },
    );

  /* =======================================================
     STATE
  ======================================================= */

  const [
    mobileMenuOpen,
    setMobileMenuOpen,
  ] = useState(false);

  const [
    selectedMember,
    setSelectedMember,
  ] = useState<
    Dict | null
  >(null);

  const [
    generatedMessage,
    setGeneratedMessage,
  ] = useState<string | null>(null);

  const [
    messageCopied,
    setMessageCopied,
  ] = useState(false);

  const [
    pendingTag,
    setPendingTag,
  ] = useState<
    string | null
  >(null);

  const [
    localAssignments,
    setLocalAssignments,
  ] = useState<
    Record<
      string,
      Assignment
    >
  >({});

  const [
    saveError,
    setSaveError,
  ] = useState<
    string | null
  >(null);

  const [
    aiPlan,
    setAiPlan,
  ] = useState<
    AIPlan | null
  >(null);

  const [
    aiGenerating,
    setAiGenerating,
  ] = useState(false);

  const [
    aiError,
    setAiError,
  ] = useState<
    string | null
  >(null);

  const [
    aiApplied,
    setAiApplied,
  ] = useState(false);

  const [
    now,
    setNow,
  ] = useState(
    Date.now(),
  );

  /* =======================================================
     CLOCK
  ======================================================= */

  useEffect(() => {
    const interval =
      window.setInterval(
        () =>
          setNow(
            Date.now(),
          ),
        1000,
      );

    return () =>
      window.clearInterval(
        interval,
      );
  }, []);

  /* =======================================================
     AUTO REFRESH
  ======================================================= */

  useEffect(() => {
    const interval =
      window.setInterval(
        () => {
          void refetch();
          void plannerQuery.refetch();
        },
        30000,
      );

    return () =>
      window.clearInterval(
        interval,
      );
  }, [
    refetch,
    plannerQuery.refetch,
  ]);

  /* =======================================================
     SERVER ASSIGNMENTS
  ======================================================= */

  const serverAssignments =
    useMemo(() => {
      const raw =
        asArray(
          plannerQuery.data
            ?.assignments,
        );

      return raw.reduce<
        Record<
          string,
          Assignment
        >
      >(
        (
          result,
          value,
        ) => {
          const tag =
            str(
              value.attacksTag,
            );

          if (!tag) {
            return result;
          }

          result[tag] = {
            warKey:
              str(
                value.warKey,
                warKey,
              ),

            attacksTag:
              tag,

            assignedTargetMapPosition:
              value.assignedTargetMapPosition ===
              null
                ? null
                : num(
                    value.assignedTargetMapPosition,
                  ),

            locked:
              Boolean(
                value.locked,
              ),

            completed:
              Boolean(
                value.completed,
              ),

            updatedAt:
              str(
                value.updatedAt,
              ),
          };

          return result;
        },
        {},
      );
    }, [
      plannerQuery.data
        ?.assignments,
      warKey,
    ]);

  useEffect(() => {
    setLocalAssignments((current) => {
      const next = {
        ...serverAssignments,
      };

      // Keep an assignment selected immediately after the user changes it.
      // The planner query can briefly return the previous server snapshot
      // while the POST/invalidation is still propagating.
      Object.entries(current).forEach(
        ([tag, local]) => {
          const server = next[tag];

          if (
            local.assignedTargetMapPosition !==
              null &&
            (!server ||
              server.assignedTargetMapPosition ===
                null)
          ) {
            next[tag] = local;
          }
        },
      );

      return next;
    });
  }, [
    serverAssignments,
  ]);

  const assignments =
    useMemo(() => {
      const merged = {
        ...serverAssignments,
        ...localAssignments,
      };

      return clanMembers.reduce<
        Record<
          string,
          Assignment
        >
      >(
        (
          result,
          member,
        ) => {
          const tag =
            str(
              member.tag,
            );

          if (!tag) {
            return result;
          }

          result[tag] =
            merged[tag] ?? {
              warKey,
              attacksTag:
                tag,
              assignedTargetMapPosition:
                null,
              locked:
                false,
              completed:
                false,
            };

          return result;
        },
        {},
      );
    }, [
      clanMembers,
      localAssignments,
      serverAssignments,
      warKey,
    ]);

  /* =======================================================
     WAR STATE
  ======================================================= */

  const warState =
    normalizeWarState(
      currentWar.state,
    );

  const countdownTarget =
    useMemo(() => {
      if (
        warState ===
        'preparation'
      ) {
        return getWarStartTimestamp(
          currentWar,
        );
      }

      if (
        warState ===
          'inwar' ||
        warState ===
          'war' ||
        warState ===
          'ongoing'
      ) {
        return getWarEndTimestamp(
          currentWar,
        );
      }

      return null;
    }, [
      currentWar.startTime,
      currentWar.warStartTime,
      currentWar.prepStartTime,
      currentWar.preparationStartTime,
      currentWar.endTime,
      currentWar.warEndTime,
      warState,
    ]);

  const countdown =
    countdownTarget !== null
      ? formatCountdown(
          countdownTarget -
            now,
        )
      : 'NO TIMER';

  const timerLabel =
    warState ===
    'preparation'
      ? 'STARTS'
      : warState ===
            'inwar' ||
          warState ===
            'war' ||
          warState ===
            'ongoing'
        ? 'ENDS'
        : 'TIME';

  /* =======================================================
     SCORE
  ======================================================= */

  const clanStars =
    num(
      clan.stars,
    );

  const opponentStars =
    num(
      opponent.stars,
    );

  const clanDestruction =
    num(
      clan.destructionPercentage,
    );

  const opponentDestruction =
    num(
      opponent.destructionPercentage,
    );

  const currentWarResult =
    useMemo(() => {
      const clanResult =
        str(
          clan.result,
        ).toLowerCase();

      const opponentResult =
        str(
          opponent.result,
        ).toLowerCase();

      if (
        clanResult === 'win' ||
        opponentResult === 'lose'
      ) {
        return 'WINNING';
      }

      if (
        clanResult === 'lose' ||
        opponentResult === 'win'
      ) {
        return 'LOSING';
      }

      if (
        clanStars >
          opponentStars ||
        (
          clanStars ===
            opponentStars &&
          clanDestruction >
            opponentDestruction
        )
      ) {
        return 'WINNING';
      }

      if (
        clanStars <
          opponentStars ||
        (
          clanStars ===
            opponentStars &&
          clanDestruction <
            opponentDestruction
        )
      ) {
        return 'LOSING';
      }

      return 'CLOSE';
    }, [
      clan.result,
      opponent.result,
      clanStars,
      opponentStars,
      clanDestruction,
      opponentDestruction,
    ]);

  /* =======================================================
     COUNTERS
  ======================================================= */

  const assignedCount =
    Object.values(
      assignments,
    ).filter(
      (assignment) =>
        assignment.assignedTargetMapPosition !==
        null,
    ).length;

  const completedCount =
    Object.values(
      assignments,
    ).filter(
      (assignment) =>
        assignment.completed,
    ).length;

  const lockedCount =
    Object.values(
      assignments,
    ).filter(
      (assignment) =>
        assignment.locked,
    ).length;

  const unassignedCount =
    Math.max(
      clanMembers.length -
        assignedCount,
      0,
    );

  /* =======================================================
     GENERATE AI
  ======================================================= */

  const generateAIPlan =
    async () => {
      setAiGenerating(true);
      setAiError(null);
      setAiPlan(null);
      setAiApplied(false);

      try {
        const clanTag =
          str(
            dashboard.clanTag,
          );

        if (!clanTag) {
          throw new Error(
            'No clan tag is available.',
          );
        }

        const response =
          await fetch(
            '/api/ai/war-planner',
            {
              method: 'POST',

              headers: {
                'Content-Type':
                  'application/json',
              },

              body:
                JSON.stringify({
                  clanTag,
                }),
            },
          );

        const body =
          await response
            .json()
            .catch(
              () => ({}),
            );

        if (!response.ok) {
          throw new Error(
            typeof body?.error ===
              'string'
              ? body.error
              : `AI War Planner returned HTTP ${response.status}`,
          );
        }

        const rawPlan =
          body?.plan;

        if (
          !rawPlan ||
          typeof rawPlan !==
            'object'
        ) {
          throw new Error(
            'The AI returned no usable war plan.',
          );
        }

        const plan =
          asDict(rawPlan);

        const recommendations =
          asArray(
            plan.recommendations,
          )
            .map(
              (value) => {
                const confidenceRaw =
                  str(
                    value.confidence,
                    'MEDIUM',
                  ).toUpperCase();

                const confidence =
                  confidenceRaw ===
                    'HIGH' ||
                  confidenceRaw ===
                    'LOW'
                    ? confidenceRaw
                    : 'MEDIUM';

                const purposeRaw =
                  str(
                    value.purpose,
                  );

                const purpose =
                  purposeRaw ===
                    '3-star attempt' ||
                  purposeRaw ===
                    'safe 2-star' ||
                  purposeRaw ===
                    'cleanup'
                    ? purposeRaw
                    : undefined;

                return {
                  attackerTag:
                    str(
                      value.attackerTag,
                    ),

                  attackerName:
                    label(
                      value.attackerName,
                      'Unknown attacker',
                    ),

                  attackerTownhall:
                    num(
                      value.attackerTownhall,
                    ),

                  attackerPosition:
                    num(
                      value.attackerPosition,
                    ),

                  targetPosition:
                    num(
                      value.targetPosition,
                    ),

                  targetName:
                    label(
                      value.targetName,
                      'Unknown target',
                    ),

                  targetTownhall:
                    num(
                      value.targetTownhall,
                    ),

                  score:
                    Math.max(
                      0,
                      Math.min(
                        100,
                        num(
                          value.score,
                        ),
                      ),
                    ),

                  confidence,

                  purpose,

                  reason:
                    label(
                      value.reason,
                      'No reason supplied.',
                    ),
                };
              },
            )
            .filter(
              (
                recommendation,
              ) =>
                recommendation.attackerPosition >
                  0 &&
                recommendation.targetPosition >
                  0,
            );

        const statusRaw =
          str(
            plan.warStatus,
            'CLOSE',
          ).toUpperCase();

        const warStatus =
          statusRaw ===
              'WINNING' ||
          statusRaw ===
              'LOSING'
            ? statusRaw
            : 'CLOSE';

        const notes =
          Array.isArray(
            plan.notes,
          )
            ? plan.notes
                .filter(
                  (
                    note: unknown,
                  ) =>
                    typeof note ===
                    'string',
                )
                .slice(
                  0,
                  10,
                )
            : [];

        setAiPlan({
          warStatus,
          summary:
            label(
              plan.summary,
              'AI generated a war plan.',
            ),
          recommendations,
          notes,
        });
      } catch (error) {
        console.error(
          'AI War Planner error:',
          error,
        );

        setAiError(
          error instanceof Error
            ? error.message
            : 'Could not generate the AI war plan.',
        );
      } finally {
        setAiGenerating(false);
      }
    };

  /* =======================================================
     SAVE ASSIGNMENT
  ======================================================= */

  const saveAssignment =
    async (
      tag: string,
      patch: Partial<Assignment>,
    ) => {
      const current =
        assignments[tag];

      if (
        !current ||
        !warKey
      ) {
        return;
      }

      const previous =
        current;

      const next: Assignment = {
        ...current,
        ...patch,
        warKey,
        attacksTag:
          tag,
      };

      setPendingTag(tag);
      setSaveError(null);

      setLocalAssignments(
        (state) => ({
          ...state,
          [tag]: next,
        }),
      );

      try {
        const response =
          await fetch(
            `/api/clash/war-planner/${encodeURIComponent(
              tag,
            )}`,
            {
              method: 'POST',

              headers: {
                'Content-Type':
                  'application/json',
              },

              body:
                JSON.stringify(
                  next,
                ),
            },
          );

        const body =
          await response
            .json()
            .catch(
              () => ({}),
            );

        if (!response.ok) {
          throw new Error(
            typeof body?.error ===
              'string'
              ? body.error
              : `Could not save assignment (HTTP ${response.status})`,
          );
        }

        await queryClient.invalidateQueries(
          {
            queryKey:
              getGetWarPlannerQueryKey(
                {
                  warKey,
                },
              ),
          },
        );
      } catch (error) {
        console.error(
          'War Planner save error:',
          error,
        );

        setSaveError(
          error instanceof Error
            ? error.message
            : 'Could not save the assignment.',
        );

        setLocalAssignments(
          (state) => ({
            ...state,
            [tag]:
              previous,
          }),
        );
      } finally {
        setPendingTag(null);
      }
    };

  /* =======================================================
     ACTIONS
  ======================================================= */

  const handleAssign =
    (
      tag: string,
      target: number | null,
    ) => {
      const current =
        assignments[tag];

      if (
        !current ||
        current.locked ||
        current.completed
      ) {
        return;
      }

      void saveAssignment(
        tag,
        {
          assignedTargetMapPosition:
            target,
        },
      );
    };

  const handleToggleLock =
    (
      tag: string,
    ) => {
      const current =
        assignments[tag];

      if (!current) {
        return;
      }

      if (
        !current.locked &&
        (
          current.completed ||
          current.assignedTargetMapPosition ===
            null
        )
      ) {
        return;
      }

      void saveAssignment(
        tag,
        {
          locked:
            !current.locked,
        },
      );
    };

  const handleComplete =
    (
      tag: string,
    ) => {
      const current =
        assignments[tag];

      if (
        !current ||
        current.completed
      ) {
        return;
      }

      if (
        current.assignedTargetMapPosition ===
        null
      ) {
        setSaveError(
          'Assign a target before marking the attack as complete.',
        );

        return;
      }

      void saveAssignment(
        tag,
        {
          completed:
            true,
        },
      );
    };

  const handleUndo =
    (
      tag: string,
    ) => {
      const current =
        assignments[tag];

      if (!current) {
        return;
      }

      void saveAssignment(
        tag,
        {
          assignedTargetMapPosition:
            null,
          locked: false,
          completed: false,
        },
      );
    };

  /* =======================================================
     APPLY AI PLAN
  ======================================================= */

  const applyAIPlan =
    async () => {
      if (
        !aiPlan ||
        aiPlan.recommendations
          .length ===
          0
      ) {
        return;
      }

      const usedTargets =
        new Set<number>();

      const availableTargets =
        new Set(
          opponentMembers
            .map(
              (member) =>
                num(
                  member.mapPosition,
                ),
            )
            .filter(
              (
                position,
              ) =>
                position >
                0,
            ),
        );

      const recommendations =
        aiPlan.recommendations.filter(
          (
            recommendation,
          ) => {
            const assignment =
              assignments[
                recommendation.attackerTag
              ];

            if (
              !assignment ||
              assignment.locked ||
              assignment.completed
            ) {
              return false;
            }

            if (
              !availableTargets.has(
                recommendation.targetPosition,
              )
            ) {
              return false;
            }

            if (
              usedTargets.has(
                recommendation.targetPosition,
              )
            ) {
              return false;
            }

            usedTargets.add(
              recommendation.targetPosition,
            );

            return true;
          },
        );

      if (
        recommendations.length ===
        0
      ) {
        setSaveError(
          'There are no unused AI recommendations to apply.',
        );

        return;
      }

      setPendingTag('__ai__');

      try {
        for (
          const recommendation of
            recommendations
        ) {
          await saveAssignment(
            recommendation.attackerTag,
            {
              assignedTargetMapPosition:
                recommendation.targetPosition,
            },
          );
        }

        setAiApplied(true);
      } finally {
        setPendingTag(null);
      }
    };

  /* =======================================================
     WAR MESSAGES
  ======================================================= */

  const generatePlayerMessage = (
    member: Dict,
  ) => {
    const tag = str(member.tag);
    const assignment = assignments[tag];

    if (
      !assignment ||
      assignment.assignedTargetMapPosition === null
    ) {
      return;
    }

    const target = opponentMembers.find(
      (opponentMember) =>
        num(opponentMember.mapPosition) ===
        assignment.assignedTargetMapPosition,
    );

    if (!target) {
      return;
    }

    const memberName = label(
      member.name,
      'Player',
    );
    const memberTH = num(
      member.townhallLevel,
      num(member.townHallLevel),
    );
    const targetPosition = num(
      target.mapPosition,
    );
    const targetName = label(
      target.name,
      'Enemy Base',
    );
    const targetTH = num(
      target.townhallLevel,
      num(target.townHallLevel),
    );

    setGeneratedMessage(
      `⚔️ WAR PLAN – YOUR ATTACK

👤 ${memberName}
🎯 Target: #${targetPosition} – ${targetName}
🏰 Town Hall: TH${memberTH} → TH${targetTH}

Your assigned target is #${targetPosition}.
Please follow the war plan and let the leadership know if anything needs to be changed.

🔥 Good luck and go for 3 stars!`,
    );
    setMessageCopied(false);
    requestAnimationFrame(() => {
      document.getElementById('war-messages')?.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    });
  };

  const generateClanMessage = () => {
    const plannedAttacks = clanMembers
      .map((member) => {
        const tag = str(member.tag);
        const assignment = assignments[tag];

        if (
          !assignment ||
          assignment.assignedTargetMapPosition === null
        ) {
          return null;
        }

        const target = opponentMembers.find(
          (opponentMember) =>
            num(opponentMember.mapPosition) ===
            assignment.assignedTargetMapPosition,
        );

        if (!target) {
          return null;
        }

        return {
          name: label(member.name, 'Player'),
          targetPosition: num(target.mapPosition),
          targetName: label(target.name, 'Enemy Base'),
        };
      })
      .filter(
        (
          attack,
        ): attack is {
          name: string;
          targetPosition: number;
          targetName: string;
        } => attack !== null,
      );

    if (plannedAttacks.length === 0) {
      setGeneratedMessage(
        '⚔️ WAR PLAN\n\nNo attack assignments have been made yet.',
      );
      setMessageCopied(false);
      return;
    }

    const assignmentLines = plannedAttacks
      .map(
        (attack, index) =>
          `${index + 1}️⃣ ${attack.name} → #${attack.targetPosition} ${attack.targetName}`,
      )
      .join('\n');

    const remaining = Math.max(
      clanMembers.length - plannedAttacks.length,
      0,
    );

    setGeneratedMessage(
      `⚔️ WAR PLAN

🎯 ATTACK ASSIGNMENTS

${assignmentLines}

${remaining > 0 ? `⚠️ ${remaining} player${remaining === 1 ? '' : 's'} still unassigned.\n` : ''}🔒 Respect assigned targets.
🧹 Follow the cleanup plan.

🔥 LET'S GET THE 3 STARS!`,
    );
    setMessageCopied(false);
    requestAnimationFrame(() => {
      document.getElementById('war-messages')?.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    });
  };

  const copyGeneratedMessage = async () => {
    if (!generatedMessage) {
      return;
    }

    try {
      await navigator.clipboard.writeText(
        generatedMessage,
      );
      setMessageCopied(true);
    } catch (error) {
      console.error(
        'Copy war message error:',
        error,
      );
      setMessageCopied(false);
    }
  };

  /* =======================================================
     REFRESH
  ======================================================= */

  const refresh =
    async () => {
      setSaveError(null);
      setAiError(null);

      await Promise.all([
        refetch(),
        plannerQuery.refetch(),
      ]);
    };

  /* =======================================================
     RENDER STATES
  ======================================================= */

  if (
    isLoading ||
    plannerQuery.isLoading
  ) {
    return <LoadingState />;
  }

  if (isError) {
    return (
      <ErrorState
        onRetry={() =>
          void refetch()
        }
      />
    );
  }

  if (
    !currentWar ||
    Object.keys(
      currentWar,
    ).length === 0
  ) {
    return (
      <EmptyWarState />
    );
  }


  /* =======================================================
     MECKA CLASH ELITE MODE
  ======================================================= */

  return (
    <div className="min-h-[100dvh] overflow-x-hidden bg-[#02070d] text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_70%_0%,rgba(0,132,255,.16),transparent_34%),radial-gradient(circle_at_10%_70%,rgba(255,174,0,.10),transparent_28%)]" />

      <div className="relative flex min-h-[100dvh]">
        <AppSidebar
          clanName={label(clan.name, 'BHABE DHEMONS')}
          clanTag={label(clan.tag, '#2Q0Q82C9R')}
          mobileOpen={mobileMenuOpen}
          onClose={() => setMobileMenuOpen(false)}
        />

        {/* MAIN */}
        <main className="relative min-w-0 flex-1">
          <div className="mx-auto max-w-[1550px] p-3 sm:p-5 xl:p-7">

                          {/* CLASH IQ BANNER */}
             <div className="mb-5 w-full overflow-hidden rounded-2xl border border-amber-400/20 bg-[#06111b] shadow-[0_18px_50px_rgba(0,0,0,.32)]">
               <img
                 src={CLASH_IQ_BANNER}
                 alt="Clash IQ"
                 className="block h-auto w-full"
                 decoding="async"
               />
             </div>

             {/* TOP BAR */}
            <header className="mb-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-[#07121d]/90 px-3 py-3 shadow-2xl backdrop-blur-xl sm:px-4">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="grid size-10 place-items-center rounded-xl border border-white/10 bg-white/5 lg:hidden"
              >
                <Menu className="size-5" />
              </button>

              <div className="hidden items-center gap-2 sm:flex">
                <span className="size-2.5 rounded-full bg-emerald-400 shadow-[0_0_14px_rgba(52,211,153,.9)]" />
                <span className="text-xs font-black uppercase tracking-[.16em] text-white/70">
                  Live War Data
                </span>
              </div>

              <div className="ml-auto flex items-center gap-2">
                <StatusPill
                  label={
                    warState === 'inwar'
                      ? 'LIVE WAR'
                      : warState === 'preparation'
                        ? 'PREPARATION'
                        : warState === 'warended'
                          ? 'ENDED'
                          : warState || 'UNKNOWN'
                  }
                  tone={warState === 'inwar' ? 'success' : 'neutral'}
                />
                <button
                  type="button"
                  onClick={() => void refresh()}
                  disabled={plannerQuery.isFetching}
                  className="grid size-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition hover:bg-white/10 disabled:opacity-50"
                >
                  <RefreshCw className={plannerQuery.isFetching ? 'size-4 animate-spin' : 'size-4'} />
                </button>
              </div>
            </header>

            {/* HERO */}
            <section className="relative mb-5 overflow-hidden rounded-[28px] border border-amber-400/20 bg-[#06111b] shadow-[0_25px_90px_rgba(0,0,0,.45)]">
              <div className="absolute inset-0">
                <img
                  src="/clashiq-hero-barbarian.png"
                  alt=""
                  className="absolute right-0 top-0 h-full w-[55%] object-cover object-left opacity-35"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-[#06111b] via-[#06111b]/90 to-transparent" />
                <div className="absolute inset-0 bg-[linear-gradient(120deg,transparent_0%,rgba(245,158,11,.06)_55%,transparent_100%)]" />
              </div>

              <div className="relative grid gap-6 p-6 sm:p-8 lg:grid-cols-[1.2fr_.8fr] lg:p-10">
                <div>
                  <div className="mb-3 flex items-center gap-2 text-[10px] font-black uppercase tracking-[.3em] text-amber-300">
                    <span className="rounded-full border border-amber-400/30 bg-amber-400/10 px-2.5 py-1">
                      Elite Mode
                    </span>
                    <span className="text-white/35">/</span>
                    War Intelligence
                  </div>
                  <h1 className="max-w-2xl text-4xl font-black tracking-[-.055em] sm:text-5xl xl:text-6xl">
                    Plan the war.
                    <br />
                    <span className="text-amber-300">Win the war.</span>
                  </h1>
                  <p className="mt-4 max-w-xl text-sm leading-6 text-white/55 sm:text-base">
                    A tactical command center for your clan — live war data,
                    intelligent targeting and AI-powered strategy.
                  </p>

                  <div className="mt-6 flex flex-wrap gap-3">
                    <button
                      type="button"
                      onClick={() => void generateAIPlan()}
                      disabled={
                        aiGenerating ||
                        clanMembers.length === 0 ||
                        opponentMembers.length === 0
                      }
                      className="inline-flex h-12 items-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-5 text-sm font-black text-black shadow-[0_8px_30px_rgba(245,158,11,.22)] transition hover:brightness-110 disabled:opacity-50"
                    >
                      {aiGenerating ? (
                        <RefreshCw className="size-4 animate-spin" />
                      ) : (
                        <Brain className="size-4" />
                      )}
                      {aiGenerating ? 'Analyzing…' : 'AI War Analysis'}
                    </button>

                    <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 text-xs font-bold text-white/65">
                      <Swords className="size-4 text-blue-300" />
                      {clanStars} — {opponentStars}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 self-end">
                  {[
                    ['OUR STARS', clanStars, 'text-blue-300'],
                    ['ENEMY STARS', opponentStars, 'text-red-300'],
                    ['ASSIGNED', `${assignedCount}/${clanMembers.length}`, 'text-amber-300'],
                    ['COMPLETED', completedCount, 'text-emerald-300'],
                  ].map(([title, value, color]) => (
                    <div
                      key={String(title)}
                      className="rounded-2xl border border-white/10 bg-black/20 p-4 backdrop-blur"
                    >
                      <p className="text-[9px] font-black uppercase tracking-[.18em] text-white/35">
                        {title}
                      </p>
                      <p className={`mt-2 text-2xl font-black ${color}`}>
                        {value}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {saveError && (
              <div className="mb-5 rounded-2xl border border-red-400/20 bg-red-500/10 p-4 text-sm text-red-200">
                <div className="flex gap-3">
                  <ShieldAlert className="size-5 shrink-0" />
                  <div>
                    <p className="font-bold">War Planner Error</p>
                    <p className="mt-1 text-red-200/70">{saveError}</p>
                  </div>
                </div>
              </div>
            )}

            {/* WAR SCOREBOARD */}
            <section className="mb-5 grid gap-4 lg:grid-cols-[1fr_auto_1fr]">
              <div className="rounded-2xl border border-blue-400/20 bg-gradient-to-br from-blue-500/10 to-transparent p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-[.2em] text-blue-300/70">
                      Our Clan
                    </p>
                    <p className="mt-1 text-lg font-black">
                      {label(clan.name, 'Our Clan')}
                    </p>
                  </div>
                  <p className="text-4xl font-black text-blue-300">{clanStars}</p>
                </div>
                <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/5">
                  <div
                    className="h-full rounded-full bg-blue-400"
                    style={{ width: `${Math.min(100, clanDestruction)}%` }}
                  />
                </div>
                <p className="mt-2 text-xs text-white/40">
                  {clanDestruction.toFixed(1)}% destruction
                </p>
              </div>

              <div className="grid place-items-center rounded-2xl border border-white/10 bg-white/[.02] px-5 py-4">
                <div className="text-[10px] font-black uppercase tracking-[.25em] text-white/30">
                  {timerLabel}
                </div>
                <div className="mt-1 font-mono text-xl font-black text-white">
                  {countdown}
                </div>
              </div>

              <div className="rounded-2xl border border-red-400/20 bg-gradient-to-br from-red-500/10 to-transparent p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-[.2em] text-red-300/70">
                      Opponent
                    </p>
                    <p className="mt-1 text-lg font-black">
                      {label(opponent.name, 'Opponent')}
                    </p>
                  </div>
                  <p className="text-4xl font-black text-red-300">{opponentStars}</p>
                </div>
                <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/5">
                  <div
                    className="h-full rounded-full bg-red-400"
                    style={{ width: `${Math.min(100, opponentDestruction)}%` }}
                  />
                </div>
                <p className="mt-2 text-xs text-white/40">
                  {opponentDestruction.toFixed(1)}% destruction
                </p>
              </div>
            </section>

            {/* AI PANEL */}
            <section className="mb-5 overflow-hidden rounded-[24px] border border-blue-400/20 bg-[#06111b]">
              <div className="flex flex-col gap-4 border-b border-white/10 bg-gradient-to-r from-blue-500/10 to-transparent p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
                <div>
                  <div className="flex items-center gap-2">
                    <div className="grid size-9 place-items-center rounded-xl bg-blue-500/15 text-blue-300">
                      <Brain className="size-5" />
                    </div>
                    <div>
                      <p className="text-[9px] font-black uppercase tracking-[.22em] text-blue-300/70">
                        Powered Intelligence
                      </p>
                      <h2 className="text-xl font-black">MECKA CLASH AI COACH</h2>
                    </div>
                  </div>
                  <p className="mt-2 max-w-2xl text-sm text-white/45">
                    Analyze your clan, read the opponent and turn live war data
                    into tactical decisions.
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => void generateAIPlan()}
                    disabled={aiGenerating}
                    className="inline-flex h-11 items-center gap-2 rounded-xl bg-blue-500 px-4 text-sm font-black text-white shadow-[0_8px_28px_rgba(59,130,246,.2)] disabled:opacity-50"
                  >
                    <Brain className="size-4" />
                    Analyze War
                  </button>
                </div>
              </div>

              {aiError && (
                <div className="m-5 rounded-2xl border border-red-400/20 bg-red-500/10 p-4 text-sm text-red-200">
                  {aiError}
                </div>
              )}

              {aiPlan ? (
                <div className="p-5 sm:p-6">
                  <div className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-black/20 p-5 lg:flex-row lg:items-start lg:justify-between">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <StatusPill
                          label={aiPlan.warStatus}
                          tone={
                            aiPlan.warStatus === 'WINNING'
                              ? 'success'
                              : aiPlan.warStatus === 'LOSING'
                                ? 'danger'
                                : 'warning'
                          }
                        />
                        <span className="text-xs font-bold text-white/45">
                          {aiPlan.recommendations.length} tactical recommendations
                        </span>
                      </div>
                      <p className="mt-3 max-w-4xl text-sm leading-6 text-white/65">
                        {aiPlan.summary}
                      </p>
                    </div>
                  </div>

                  {aiPlan.recommendations.length > 0 && (
                    <div className="mt-4 grid gap-3 md:grid-cols-2">
                      {aiPlan.recommendations.map((recommendation, index) => (
                        <RecommendationCard
                          key={`${recommendation.attackerTag}-${recommendation.targetPosition}-${index}`}
                          recommendation={recommendation}
                        />
                      ))}
                    </div>
                  )}

                  {aiPlan.notes.length > 0 && (
                    <div className="mt-4 rounded-2xl border border-white/10 bg-white/[.02] p-4">
                      <p className="text-[9px] font-black uppercase tracking-[.2em] text-white/35">
                        AI Notes
                      </p>
                      <ul className="mt-2 space-y-1 text-sm text-white/55">
                        {aiPlan.notes.map((note, index) => (
                          <li key={`${note}-${index}`}>• {note}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ) : (
                <div className="grid place-items-center px-6 py-10 text-center">
                  <Brain className="size-10 text-white/10" />
                  <p className="mt-3 font-bold">Ready for tactical analysis</p>
                  <p className="mt-1 max-w-md text-sm text-white/35">
                    Run AI analysis when you want ClashIQ to evaluate the live war.
                  </p>
                </div>
              )}
            </section>

            {/* OPPONENT INTELLIGENCE */}
            <OpponentAttackHistory
              opponents={opponentMembers}
              ourMembers={clanMembers}
            />

            {/* ATTACK PLAN */}
            <section className="mt-5 overflow-hidden rounded-[24px] border border-amber-400/15 bg-[#06111b]">
              <div className="border-b border-white/10 bg-gradient-to-r from-amber-400/10 to-transparent p-5 sm:p-6">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-[.24em] text-amber-300/70">
                      Command Board
                    </p>
                    <h2 className="mt-1 text-2xl font-black">WAR PLANNER</h2>
                    <p className="mt-1 text-sm text-white/40">
                      Assign targets, lock decisions and track execution.
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <StatusPill label={`${assignedCount} assigned`} tone="info" />
                    <StatusPill label={`${unassignedCount} unassigned`} tone="neutral" />
                    <StatusPill label={`${lockedCount} locked`} tone="warning" />
                    <StatusPill label={`${completedCount} complete`} tone="success" />
                  </div>
                </div>
              </div>

              {clanMembers.length === 0 ? (
                <div className="p-10 text-center text-white/40">No war members.</div>
              ) : (
                <div>
                  {clanMembers.map((member) => {
                    const tag = str(member.tag);
                    const assignment = assignments[tag];
                    if (!assignment) return null;

                    return (
                      <PlannerRow
                        key={tag}
                        member={member}
                        assignment={assignment}
                        opponents={opponentMembers}
                        pending={pendingTag === tag || pendingTag === '__ai__'}
                        onAssign={(target) => handleAssign(tag, target)}
                        onToggleLock={() => handleToggleLock(tag)}
                        onComplete={() => handleComplete(tag)}
                        onUndo={() => handleUndo(tag)}
                        onOpenMember={() => setSelectedMember(member)}
                        onGenerateMessage={() => generatePlayerMessage(member)}
                      />
                    );
                  })}
                </div>
              )}
            </section>

            {/* WAR MESSAGES */}
            <section id="war-messages" className="mt-5 overflow-hidden rounded-[24px] border border-amber-400/20 bg-[#06111b]">
              <div className="border-b border-white/10 bg-gradient-to-r from-amber-400/10 to-transparent p-5 sm:p-6">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-[.24em] text-amber-300/70">
                      Communication
                    </p>
                    <h2 className="mt-1 text-2xl font-black">
                      WAR MESSAGES
                    </h2>
                    <p className="mt-1 max-w-2xl text-sm text-white/40">
                      Generate ready-to-copy English messages for individual players or the whole clan.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={generateClanMessage}
                    disabled={assignedCount === 0}
                    className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-5 text-sm font-black text-black shadow-[0_8px_30px_rgba(245,158,11,.18)] transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <Users className="size-4" />
                    Generate Message for Whole Clan
                  </button>
                </div>
              </div>

              {generatedMessage ? (
                <div className="p-5 sm:p-6">
                  <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
                    <pre className="whitespace-pre-wrap font-sans text-sm leading-6 text-white/80">
                      {generatedMessage}
                    </pre>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => void copyGeneratedMessage()}
                      className="inline-flex h-10 items-center gap-2 rounded-xl bg-amber-400 px-4 text-sm font-black text-black transition hover:brightness-110"
                    >
                      <Copy className="size-4" />
                      {messageCopied ? 'Copied!' : 'Copy Message'}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setGeneratedMessage(null);
                        setMessageCopied(false);
                      }}
                      className="inline-flex h-10 items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 text-sm font-bold text-white/70 transition hover:bg-white/10 hover:text-white"
                    >
                      <X className="size-4" />
                      Close
                    </button>
                  </div>

                  <p className="mt-3 text-[10px] text-white/30">
                    Copy the message and send it through your preferred clan communication channel.
                  </p>
                </div>
              ) : (
                <div className="grid place-items-center px-6 py-8 text-center">
                  <Copy className="size-8 text-amber-300/20" />
                  <p className="mt-3 font-bold text-white/70">
                    No message generated yet
                  </p>
                  <p className="mt-1 max-w-md text-sm text-white/30">
                    Use “Generate Message” beside a player or generate one message for the whole clan.
                  </p>
                </div>
              )}
            </section>

            <footer className="mt-5 grid gap-3 md:grid-cols-3">
              {[
                [Target, 'Smart Targeting', 'Use matchup data to prioritize the right base.'],
                [Lock, 'Lock the Plan', 'Freeze assignments when your strategy is set.'],
                [Clock3, 'Live Intelligence', 'Refresh the board as the war develops.'],
              ].map(([Icon, title, text]) => (
                <div
                  key={String(title)}
                  className="rounded-2xl border border-white/10 bg-[#06111b] p-5"
                >
                  <div className="flex items-start gap-3">
                    <div className="grid size-9 shrink-0 place-items-center rounded-xl bg-white/5 text-amber-300">
                      <Icon className="size-4" />
                    </div>
                    <div>
                      <p className="font-bold">{title}</p>
                      <p className="mt-1 text-xs leading-5 text-white/35">{text}</p>
                    </div>
                  </div>
                </div>
              ))}
            </footer>
          </div>
        </main>
      </div>

      {selectedMember && (
        <MemberDetailsDialog
          member={selectedMember}
          open={Boolean(selectedMember)}
          onOpenChange={(open) => {
            if (!open) setSelectedMember(null);
          }}
        />
      )}
    </div>
  );
}
